# python-allrecipes
##### v0.1.6

Python API to search &amp; get recipes from the 'allrecipes.com' website (web crawler, unofficial)  
Useful, efficient and super simple to use.  

### Installation :
`pip install python-latin-expr-fr`  


### Requirements :
`python >= 3.4`  

###### Support / Contact : remaudcorentin.dev@gmail.com
